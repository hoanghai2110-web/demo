'use client'

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useState, useRef, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Menu, User, ThumbsUp, ThumbsDown, Copy, Send, Edit } from 'lucide-react'

interface Message {
  id: string
  type: 'user' | 'ai'
  content: string
  timestamp: Date
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'user',
      content: 'How are you?',
      timestamp: new Date()
    },
    {
      id: '2',
      type: 'ai',
      content: "As an AI language model, I don't have feelings or emotions like humans do, so I'm not capable of feeling sad or any other emotion. I'm designed to assist and provide information to users to the best of my ability. How can I assist you today?",
      timestamp: new Date()
    }
  ])
  const [inputValue, setInputValue] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue.trim(),
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setIsLoading(true)

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: "I'm here to help! What would you like to know or discuss?",
        timestamp: new Date()
      }
      setMessages(prev => [...prev, aiMessage])
      setIsLoading(false)
    }, 1000)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const handleCopyMessage = (content: string) => {
    navigator.clipboard.writeText(content)
  }

  const handleProfileClick = () => {
    router.push('/profile')
  }

  return (
    <div className="h-screen bg-[#f2efe4] flex flex-col font-['Rubik']">
      {/* Fixed Header */}
      <header className="flex-shrink-0 px-5 py-3 flex items-center justify-between bg-[#f2efe4]">
        <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
          <Menu className="h-6 w-6 text-[#101010]" strokeWidth={2} />
        </Button>
        
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-8 w-8 p-0 rounded-full bg-[#101010] hover:bg-[#262522]"
          onClick={handleProfileClick}
        >
          <User className="h-5 w-5 text-white" />
        </Button>
      </header>

      {/* Scrollable Chat Messages Area */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.map((message) => (
          <div key={message.id}>
            {message.type === 'user' ? (
              <div className="flex items-start justify-end space-x-2 mb-4">
                <Button variant="ghost" size="icon" className="h-6 w-6 mt-3 p-0">
                  <Edit className="h-4 w-4 text-[#101010]" />
                </Button>
                <div className="bg-[#fffbf2] rounded-xl px-3 py-3 max-w-[280px] rounded-br-sm">
                  <p className="text-[17px] leading-[22px] text-[#403e39] font-normal">
                    {message.content}
                  </p>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-xl px-3 py-3 max-w-[335px] rounded-bl-sm mb-4">
                <p className="text-[17px] leading-[22px] text-[#403e39] font-normal mb-4">
                  {message.content}
                </p>
                
                {/* Separator line */}
                <div className="w-full h-[2px] bg-[#e9e4d6] mb-4"></div>
                
                {/* Action buttons */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Button variant="ghost" size="icon" className="h-6 w-6 p-0">
                      <ThumbsUp className="h-6 w-6 text-[#101010]" strokeWidth={1.5} />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-6 w-6 p-0">
                      <ThumbsDown className="h-6 w-6 text-[#101010]" strokeWidth={1.5} />
                    </Button>
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-auto p-0 hover:bg-transparent flex items-center space-x-1"
                    onClick={() => handleCopyMessage(message.content)}
                  >
                    <Copy className="h-5 w-5 text-[#101010]" strokeWidth={1.5} />
                    <span className="text-[17px] text-[#101010] font-normal">Copy</span>
                  </Button>
                </div>
              </div>
            )}
          </div>
        ))}
        
        {isLoading && (
          <div className="bg-white rounded-xl rounded-bl-sm px-3 py-3 max-w-[335px] mb-4">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-[#a6a39d] rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-[#a6a39d] rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-[#a6a39d] rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Fixed Input Field */}
      <div className="flex-shrink-0 px-4 pb-6 pt-2 bg-[#f2efe4]">
        <div className="relative bg-white border border-[#e9e4d6] rounded-xl">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask me anything..."
            className="h-[70px] bg-transparent border-0 rounded-xl text-[17px] text-[#101010] placeholder:text-[#a6a39d] px-4 pr-16 font-['Rubik']"
            disabled={isLoading}
          />
          <Button
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || isLoading}
            variant="ghost"
            size="icon"
            className="absolute right-4 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
          >
            <Send className="h-6 w-6 text-[#a6a39d]" />
          </Button>
        </div>
      </div>
    </div>
  )
}
