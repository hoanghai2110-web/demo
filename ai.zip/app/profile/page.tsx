'use client'

import { ArrowLeft, User, Bell, Globe, FileText, LogOut, ChevronRight } from 'lucide-react'
import { useRouter } from "next/navigation"
import { useState } from "react"
import { Switch } from "@/components/ui/switch"

export default function ProfilePage() {
  const router = useRouter()
  const [notificationsEnabled, setNotificationsEnabled] = useState(true)

  const handleBack = () => {
    router.push('/chat')
  }

  const handleLogout = () => {
    // Handle logout logic here
    console.log('Logging out...')
    router.push('/login')
  }

  const menuItems = [
    {
      icon: User,
      label: "Edit Profile",
      onClick: () => console.log('Edit Profile'),
      rightElement: <ChevronRight className="w-5 h-5 text-[#403e39]" />
    },
    {
      icon: Bell,
      label: "Notifications",
      onClick: () => setNotificationsEnabled(!notificationsEnabled),
      rightElement: (
        <Switch
          checked={notificationsEnabled}
          onCheckedChange={setNotificationsEnabled}
          className="data-[state=checked]:bg-[#101010] data-[state=unchecked]:bg-gray-200"
        />
      )
    },
    {
      icon: Globe,
      label: "Languages",
      onClick: () => console.log('Languages'),
      rightElement: <ChevronRight className="w-5 h-5 text-[#403e39]" />
    },
    {
      icon: FileText,
      label: "Terms of service",
      onClick: () => console.log('Terms of service'),
      rightElement: <ChevronRight className="w-5 h-5 text-[#403e39]" />
    },
    {
      icon: FileText,
      label: "Privacy Policy",
      onClick: () => console.log('Privacy Policy'),
      rightElement: <ChevronRight className="w-5 h-5 text-[#403e39]" />
    },
    {
      icon: LogOut,
      label: "Log out",
      onClick: handleLogout,
      rightElement: <ChevronRight className="w-5 h-5 text-[#403e39]" />
    }
  ]

  return (
    <div className="min-h-screen bg-[#f2efe4] font-['Rubik']">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#f2efe4]">
        <button
          onClick={handleBack}
          className="p-2 hover:bg-black/5 rounded-full transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-[#101010]" />
        </button>
        <h1 className="text-[15px] font-normal text-[#262521]">Profile</h1>
        <div className="w-9" /> {/* Spacer for centering */}
      </div>

      <div className="px-4">
        {/* Profile Section */}
        <div className="flex flex-col items-center mt-6 mb-8">
          {/* Profile Image */}
          <div className="w-20 h-20 mb-4">
            <div className="w-full h-full rounded-full bg-[#e6e1d6] flex items-center justify-center">
              <User className="w-8 h-8 text-[#403e39]" />
            </div>
          </div>
          
          {/* User Info */}
          <div className="text-center space-y-1">
            <h2 className="text-[22px] font-medium text-[#262521] leading-[28px]">
              Shambhavi Mishra
            </h2>
            <p className="text-[16px] font-normal text-[#403e39] leading-[20px]">
              @m.shambhavi
            </p>
          </div>
        </div>

        {/* Menu Items */}
        <div className="space-y-0">
          {menuItems.map((item, index) => {
            const IconComponent = item.icon
            return (
              <div key={index}>
                <button
                  onClick={item.onClick}
                  className="w-full flex items-center justify-between px-6 py-4 hover:bg-black/5 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <IconComponent className="w-5 h-5 text-[#403e39]" />
                    <span className="text-[16px] font-normal text-[#403e39] leading-[20px]">
                      {item.label}
                    </span>
                  </div>
                  {item.rightElement}
                </button>
                {index < menuItems.length - 1 && (
                  <div className="border-b border-[#e9e4d1] mx-6" />
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
